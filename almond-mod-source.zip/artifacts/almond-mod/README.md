# Almond Mod — Minecraft Forge 1.20.1

## Что добавляет мод

### Особый Миндаль (Special Almond)
Новый предмет еды. При употреблении даёт 3 эффекта на **3 минуты**:

| Эффект | Уровень | Описание |
|--------|---------|----------|
| Сила (Strength) | III | +мощь атаки |
| Скорость (Speed) | III | +быстрое передвижение |
| Рикошет (Ricochet) | III | Мобы отлетают далеко при ударе |

### Эффект Рикошет
Пока активен — каждый удар по мобу отбрасывает его в сторону от игрока:
- **Уровень 1** — небольшой отброс
- **Уровень 2** — средний отброс  
- **Уровень 3** — очень сильный отброс (мобы улетают далеко!)

### Рецепт крафта (верстак, бесформенный)
- 1x Золотое Яблоко
- 1x Сахар
- 1x Порошок Пламени (Blaze Powder)

## Как установить

1. Установи [Minecraft Forge 1.20.1](https://files.minecraftforge.net/) (версия 47.2.0+)
2. Скачай `.jar` файл мода
3. Положи его в папку `.minecraft/mods/`
4. Запусти игру

## Как собрать из исходников

### Требования
- Java 17 (JDK)
- IntelliJ IDEA (рекомендуется) или любая другая IDE

### Сборка
```bash
# Скачай Gradle wrapper
./gradlew wrapper

# Настройка для Eclipse
./gradlew eclipse

# Настройка для IntelliJ IDEA
./gradlew genIntellijRuns

# Сборка .jar файла
./gradlew build
```

Готовый `.jar` будет в папке `build/libs/`.

### Запуск в разработке
```bash
./gradlew runClient   # запустить Minecraft клиент
./gradlew runServer   # запустить сервер
```

## Текстура предмета

Добавь файл текстуры по пути:
```
src/main/resources/assets/almondmod/textures/item/special_almond.png
```
Размер: **16x16 пикселей** (стандарт Minecraft).

## Структура проекта

```
src/main/java/com/almondmod/almondmod/
├── AlmondMod.java              ← точка входа мода
├── init/
│   ├── ModEffects.java         ← регистрация эффектов
│   └── ModItems.java           ← регистрация предметов
├── effects/
│   └── RicochetEffect.java     ← класс эффекта Рикошет
├── items/
│   └── SpecialAlmondItem.java  ← класс Особого Миндаля
└── events/
    └── RicochetEventHandler.java ← логика отброса при ударе
```
