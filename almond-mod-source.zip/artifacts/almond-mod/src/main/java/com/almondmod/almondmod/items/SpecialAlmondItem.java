package com.almondmod.almondmod.items;

import com.almondmod.almondmod.init.ModEffects;
import net.minecraft.advancements.CriteriaTriggers;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * Особый Миндаль — при употреблении в пищу даёт:
 *   - Сила III (Strength III) на 3 минуты
 *   - Скорость III (Speed III) на 3 минуты
 *   - Рикошет III (Ricochet III) на 3 минуты
 */
public class SpecialAlmondItem extends Item {

    private static final int EFFECT_DURATION_TICKS = 20 * 60 * 3; // 3 минуты
    private static final int EFFECT_AMPLIFIER = 2; // уровень 3 (0-based)

    public SpecialAlmondItem() {
        super(new Item.Properties()
                .food(new FoodProperties.Builder()
                        .nutrition(4)
                        .saturationMod(0.6f)
                        .alwaysEat()
                        .build()));
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity livingEntity) {
        ItemStack result = super.finishUsingItem(stack, level, livingEntity);

        if (!level.isClientSide()) {
            // Сила III
            livingEntity.addEffect(new MobEffectInstance(
                    MobEffects.DAMAGE_BOOST,
                    EFFECT_DURATION_TICKS,
                    EFFECT_AMPLIFIER,
                    false,
                    true,
                    true
            ));

            // Скорость III
            livingEntity.addEffect(new MobEffectInstance(
                    MobEffects.MOVEMENT_SPEED,
                    EFFECT_DURATION_TICKS,
                    EFFECT_AMPLIFIER,
                    false,
                    true,
                    true
            ));

            // Рикошет III
            livingEntity.addEffect(new MobEffectInstance(
                    ModEffects.RICOCHET.get(),
                    EFFECT_DURATION_TICKS,
                    EFFECT_AMPLIFIER,
                    false,
                    true,
                    true
            ));

            if (livingEntity instanceof ServerPlayer serverPlayer) {
                CriteriaTriggers.CONSUME_ITEM.trigger(serverPlayer, stack);
            }
        }

        return result;
    }
}
