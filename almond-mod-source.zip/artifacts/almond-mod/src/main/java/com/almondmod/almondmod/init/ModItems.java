package com.almondmod.almondmod.init;

import com.almondmod.almondmod.AlmondMod;
import com.almondmod.almondmod.items.SpecialAlmondItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, AlmondMod.MOD_ID);

    public static final RegistryObject<Item> SPECIAL_ALMOND =
            ITEMS.register("special_almond", SpecialAlmondItem::new);
}
