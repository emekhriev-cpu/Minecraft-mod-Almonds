package com.almondmod.almondmod.effects;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeMap;

/**
 * Ricochet Effect — при ударе по мобу отбрасывает его.
 * Уровень 1 = слабый отброс, уровень 3 = очень сильный.
 * Логика отброса применяется в RicochetEventHandler.
 */
public class RicochetEffect extends MobEffect {

    public RicochetEffect() {
        super(MobEffectCategory.BENEFICIAL, 0xFFAA00);
    }

    @Override
    public void applyEffectTick(LivingEntity entity, int amplifier) {
    }

    @Override
    public boolean isDurationEffectTick(int duration, int amplifier) {
        return false;
    }

    @Override
    public void addAttributeModifiers(LivingEntity entity, AttributeMap attributeMap, int amplifier) {
        super.addAttributeModifiers(entity, attributeMap, amplifier);
    }
}
