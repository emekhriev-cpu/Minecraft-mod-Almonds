package com.almondmod.almondmod.init;

import com.almondmod.almondmod.AlmondMod;
import com.almondmod.almondmod.effects.RicochetEffect;
import net.minecraft.world.effect.MobEffect;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEffects {

    public static final DeferredRegister<MobEffect> EFFECTS =
            DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, AlmondMod.MOD_ID);

    public static final RegistryObject<MobEffect> RICOCHET =
            EFFECTS.register("ricochet", RicochetEffect::new);
}
