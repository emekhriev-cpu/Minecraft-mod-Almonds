package com.almondmod.almondmod.events;

import com.almondmod.almondmod.AlmondMod;
import com.almondmod.almondmod.init.ModEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Обработчик события удара.
 * Если игрок имеет эффект Рикошет, цель отбрасывается при ударе.
 * Уровень 1 — небольшой отброс, уровень 3 — очень сильный.
 */
@Mod.EventBusSubscriber(modid = AlmondMod.MOD_ID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public class RicochetEventHandler {

    @SubscribeEvent
    public static void onLivingHurt(LivingHurtEvent event) {
        LivingEntity target = event.getEntity();

        // Проверяем: источник урона — игрок?
        if (event.getSource().getEntity() instanceof Player attacker) {

            MobEffectInstance ricochetEffect = attacker.getEffect(ModEffects.RICOCHET.get());
            if (ricochetEffect == null) return;

            int level = ricochetEffect.getAmplifier(); // 0, 1 или 2 (уровни 1, 2, 3)

            // Сила отброса зависит от уровня эффекта
            double horizontalStrength = 1.5 + (level * 1.5); // 1.5 / 3.0 / 4.5
            double verticalStrength = 0.5 + (level * 0.3);   // 0.5 / 0.8 / 1.1

            // Направление от игрока к цели
            Vec3 attackerPos = attacker.position();
            Vec3 targetPos = target.position();
            Vec3 direction = targetPos.subtract(attackerPos).normalize();

            // Применяем отброс
            target.setDeltaMovement(
                    direction.x * horizontalStrength,
                    verticalStrength,
                    direction.z * horizontalStrength
            );
            target.hurtMarked = true;
        }
    }
}
